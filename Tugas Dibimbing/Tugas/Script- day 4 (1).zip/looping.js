// // for statement

// console.log("Im Wrong");
// console.log("Im Wrong");
// console.log("Im Wrong");
// console.log("Im Wrong");

// for (let i = 1; i <= 5; i++) {
//     for (let j = 0; j <= 3; j++) {
//         console.log(j);
//     }
// }

// let cars = ["toyota", "tesla", "marcedes"];
// console.log(cars.length);
// for (let i = 0; i < cars.length; i++) {
//     if (cars[i] === "tesla") {
//         console.log(cars[i]);
//     }
// }


// while statement
let num = 6;
while (num < 6) { //ngecek konsisinya dulu baru menjalankan console
    console.log(`The Number is ${num}`);
    num++;
}

console.log('----------');

// do while statement
do { //melakukan console dulu baru ngecek kondisi
    console.log(`The Number is ${num}`);
    num++;
} while (num < 5);