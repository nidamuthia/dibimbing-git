
// console.log("Genap");
// for (let index = 1; index <= 100; index++) {
//     if (index % 2 == 0) {
//         console.log(index);
//     }
    
// }


// console.log("Ganjil");
// for (let index = 1; index <= 100; index++) {
//     if (index % 2 == 1) {
//         console.log(index);
//     }
    
// }

// let num = 0;
// console.log(num.toFixed(2));
