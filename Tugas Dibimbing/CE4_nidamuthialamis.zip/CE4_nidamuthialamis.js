data ="AAAABBBCDFFFDAABBBCG"

const newData = Array.from(new Set(data))

console.log(newData)